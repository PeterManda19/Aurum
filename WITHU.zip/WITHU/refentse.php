<link rel="stylesheet" href="css/fentse.css">

<!DOCTYPE html>
<html lang="en">

<?php

include_once 'includes/header.php';
?>
<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Food donation</title>
    <link rel="stylesheet" href="fentse.css">
</head>

<body>
    <!-- Start Landing Page -->
    <div class="landing-page">
        
        <div class="content">
            
            <div class="container">
                <div class="info">
                    <br>
                    <br>
                    <br>
                    <br>
                    <h1> Help A Student Initiative</h1>
                    <p id="beneficiaries">Meet one of our beneficiaries</p>
                    <br>
                    <br>
                    <br>
                    <br>
                    <p>" WithU helped me gain my confidence back, with skin care products. I had major breakouts that looked really horrible as they were too big on my face. I was just so embarrassed to go to class and would sometimes miss class on my worse
                        days when my confidence levels were on the ground. I was sent money to go see a doctor who prescribed some medication for me. My skin is getting so much better now and I am now attending all my classes." <br>-Refentse Sekgobela
                    </p>
                    <p id="beneficiaries">Meet one of our beneficiaries</p>
                    <button>Donation closed.</button>
                </div>
                <div class="image">
                    <img src="images/refentse21st.jpg">
                </div>
            </div>
        </div>
    </div>
    <!-- End Landing Page -->
</body>

</html>