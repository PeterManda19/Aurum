<!DOCTYPE html>
<html lang="en">
<link rel="stylesheet" href="css/mali.css">
<?php

include_once 'includes/header.php';
?>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Food donation</title>
    <link rel="stylesheet" href="marley.css">
</head>

<body>
    <!-- Start Landing Page -->
    <div class="landing-page">
        <header>
          
        </header>
        <div class="content">
            <div class="container">
                <div class="info">
                    <h1> Help A Student Initiative</h1>
                    <p id="beneficiaries">Meet one of our beneficiaries</p>
                    <br>
                    <br>
                    <br>
                    <br>
                    <p>" I was so close to dropping out, WithU helped me secure food donations by giving me a voucher so i can shop at any grocery shop. I am so grateful and wish they go stronger so they can continue helping students who are in need just
                        like I was. I am finally a graduate and will definitely also donate to those in need through WithU." <br>-Marley Mrwetyana
                    </p>
                    <p id="beneficiaries">Meet one of our beneficiaries</p>
                    <button>Donation closed.</button>
                </div>
                <div class="image">
                    <img src="images/mali.png">
                </div>
            </div>
        </div>
    </div>
    <!-- End Landing Page -->
</body>

</html>