<?php 
		 
			define('EMAIL', 'your mail');
			define('PASS', 'your pass');
			define('HOST', 'smtp.gmail.com');

?>

