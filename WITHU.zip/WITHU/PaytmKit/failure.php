<?php


// Salt should be same Post Request 
?>
<!DOCTYPE html>
<html>
<head>
</head>
<body>
	<div>
		<h2>Payment Failure</h2>
	</div>

        please try again.....
</body>
<script>
setTimeout(function(){window.location.replace('<?php  echo 'https://dodonation.000webhostapp.com/donation_form.php';?>');}, 10000);

</script>
</html>