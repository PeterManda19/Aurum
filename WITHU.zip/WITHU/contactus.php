<html lang="en">
  <head>
    <link rel="stylesheet" href="css/Firstcampaign.css">


	<!-- Modernizr JS -->
	<script src="js/Firstcampaign.js"></script>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB" crossorigin="anonymous">

    <link rel="stylesheet" type="text/css" href="source/main.css">
    
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css" integrity="sha384-lKuwvrZot6UHsBSfcMvOkWwlCMgc0TaWr+30HWe3a4ltaBwTZhyTEggF5tJv8tbt" crossorigin="anonymous">

    <title>WithU</title>
  </head>
  <body>

  
    <?php
    include_once 'includes/header.php';
    ?>


   

    <!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.12.0-2/css/all.min.css" integrity="sha256-46r060N2LrChLLb5zowXQ72/iKKNiw/lAmygmHExk/o=" crossorigin="anonymous" />
    <link rel="stylesheet" href="css/contactuscss.css">
    <section>
</head>

<body>

    <section>
        <div class="container">
            <div class="contactinfo">
                <div>
                    <h2>Contact Info</h2>
                    <ul class="info">
                        <li>
                            <span><i class="fas fa-street-view"></i></span>
                            <span>My Address, 40 bunting , Cottlesoe, Auckland park , 2092</span>
                        </li>
                        <li>
                            <span><i class="fa fa-envelope" aria-hidden="true"></i></span>
                            <span>Seipatifrans17@gmail.com</span>
                        </li>
                        <li>
                            <span><i class="fas fa-phone-alt"></i></span>
                            <span>+27795672466</span>
                        </li>
                    </ul>
                </div>
                <ul class="sci">
                    <li><a><i class="fab fa-instagram fa-2x"></i></a></li>
                    <li><a><i class="fab fa-pinterest-p fa-2x"></i></a></li>
                    <li><a><i class="fab fa-linkedin-in fa-2x"></i></a></li>
                    <li><a><i class="fab fa-twitter fa-2x"></i></a></li>
                </ul>
            </div>
            <div class="contactForm">
                <h2>Send a message</h2>
                <div class="formBox">
                    <div class="inputBox w50">
                        <input type="text" name="" required>
                        <span>First name</span>
                    </div>
                    <div class="inputBox w50">
                        <input type="text" name="" required>
                        <span>Last name</span>
                    </div>
                    <div class="inputBox w50">
                        <input type="text" name="" required/>
                        <span>Email</span>
                    </div>
                    <div class="inputBox w50">
                        <input type="text" name="" required>
                        <span>Mobile Number</span>
                    </div>
                    <div class="inputBox w100">
                        <textarea required name=""></textarea>
                        <span>Write your message here...</span>
                    </div>
                    <div class="inputBox w100">
                        <input type="submit" value="Send" />
                    </div>
                </div>
            </div>
        </div>
    </section>
</body>

</html>