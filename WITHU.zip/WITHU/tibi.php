<!DOCTYPE html>
<html lang="en">
<link rel="stylesheet" href="css/tibi.css">

<?php


include_once 'includes/header.php';
?>
<br>
<br>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Food donation</title>
    <link rel="stylesheet" href="styleprac.css">
</head>

<br>
<br>
<body>
    <!-- Start Landing Page -->
    <div class="landing-page">
    
        <div class="content">
            <div class="container">
                <div class="info">
                    <h1> Help A Student Initiative</h1>
                    <p id="beneficiaries">Meet one of our beneficiaries</p>
                  


                    <p>"I ran out of money! to buy food just in the middle of the month, GOG did give us food parcels but they weren’t enough to keep me going for the whole month. I then went to WithU to seek help and they really helped by gifting me with
                        a pick ‘n pay voucher. Thank you so much guys for all the contributions that contributed towards the voucher." <br>-Tebello Soebe</p>
                    <p id="beneficiaries">Meet one of our beneficiaries</p>
                    <button>Donation closed.</button>
                </div>
                <div class="image">
                    <img src="images/tebello3.jpg">
                </div>
            </div>
        </div>
    </div>
    <!-- End Landing Page -->
</body>

</html>